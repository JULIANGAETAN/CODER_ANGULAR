module.exports = {
  singleQuote: true,
  printWidth: 100,
  trailingComma: 'es5',
};