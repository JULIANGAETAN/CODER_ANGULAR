import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatTableModule } from '@angular/material/table';
import { MatIconModule } from '@angular/material/icon';
import { MatPaginatorModule } from '@angular/material/paginator';

import { InscripcionesService } from '../../services/inscripciones.service';
import { Inscripcion } from '../../models/inscripcion.model';
import { AlumnosService } from '../../../alumnos/services/alumnos.service';
import { CursosService } from '../../../cursos/services/cursos.service';
import { Alumno } from '../../../alumnos/models/alumno.model';
import { Curso } from '../../../cursos/models/curso.model';

@Component({
  selector: 'app-inscripciones-list',
  standalone: true,
  templateUrl: './inscripciones-list.component.html',
  styleUrls: ['./inscripciones-list.component.scss'],
  imports: [
    CommonModule,
    FormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatTableModule,
    MatIconModule,
    MatPaginatorModule,
  ],
})
export class InscripcionesListComponent implements OnInit {
  inscripciones: Inscripcion[] = [];
  alumnos: Alumno[] = [];
  cursos: Curso[] = [];

  filtro = '';

  displayedColumns = ['id', 'alumno', 'curso', 'fecha', 'acciones'];

  constructor(
    private inscripcionesService: InscripcionesService,
    private alumnosService: AlumnosService,
    private cursosService: CursosService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.cargar();
  }

  cargar(): void {
    this.inscripcionesService
      .listar()
      .subscribe((lista) => (this.inscripciones = lista));

    this.alumnosService.listar().subscribe((lista) => (this.alumnos = lista));
    this.cursosService.listar().subscribe((lista) => (this.cursos = lista));
  }

  aplicarFiltro(): Inscripcion[] {
    const f = this.filtro.toLowerCase();
    return this.inscripciones.filter(
      (i) =>
        i.id.toLowerCase().includes(f) ||
        i.alumnoId.toLowerCase().includes(f) ||
        i.cursoId.toLowerCase().includes(f)
    );
  }

  getAlumnoNombre(id: string): string {
    const a = this.alumnos.find((x) => x.id === id);
    return a ? `${a.nombre} ${a.apellido}` : id;
  }

  getCursoNombre(id: string): string {
    const c = this.cursos.find((x) => x.id === id);
    return c ? c.nombre : id;
  }

  nueva(): void {
    this.router.navigate(['/inscripciones/nueva']);
  }

  editar(insc: Inscripcion): void {
    this.router.navigate(['/inscripciones', insc.id]);
  }

  eliminar(id: string): void {
    this.inscripcionesService.eliminar(id);
    this.cargar();
  }

  restaurar(): void {
    this.inscripcionesService.reset();
    this.cargar();
  }
}
