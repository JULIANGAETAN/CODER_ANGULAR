import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  FormBuilder,
  FormGroup,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';

import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatSelectModule } from '@angular/material/select';
import { MatOptionModule } from '@angular/material/core';

import { InscripcionesService } from '../../services/inscripciones.service';
import { Inscripcion } from '../../models/inscripcion.model';
import { AlumnosService } from '../../../alumnos/services/alumnos.service';
import { CursosService } from '../../../cursos/services/cursos.service';
import { Alumno } from '../../../alumnos/models/alumno.model';
import { Curso } from '../../../cursos/models/curso.model';

@Component({
  selector: 'app-inscripciones-form',
  standalone: true,
  templateUrl: './inscripciones-form.component.html',
  styleUrls: ['./inscripciones-form.component.scss'],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatSelectModule,
    MatOptionModule,
  ],
})
export class InscripcionesFormComponent implements OnInit {
  form: FormGroup;
  titulo = 'Nueva inscripción';
  idEditar: string | null = null;

  alumnos: Alumno[] = [];
  cursos: Curso[] = [];

  constructor(
    private fb: FormBuilder,
    private inscripcionesService: InscripcionesService,
    private alumnosService: AlumnosService,
    private cursosService: CursosService,
    private router: Router,
    private route: ActivatedRoute
  ) {
    this.form = this.fb.group({
      alumnoId: ['', Validators.required],
      cursoId: ['', Validators.required],
      fecha: ['', Validators.required],
    });
  }

  ngOnInit(): void {
    // cargo combos
    this.alumnosService.listar().subscribe((lista) => (this.alumnos = lista));
    this.cursosService.listar().subscribe((lista) => (this.cursos = lista));

    // si vengo a editar
    const id = this.route.snapshot.paramMap.get('id');
    if (id) {
      const insc = this.inscripcionesService.obtenerPorId(id);
      if (insc) {
        this.idEditar = id;
        this.titulo = 'Editar inscripción';
        this.form.patchValue({
          alumnoId: insc.alumnoId,
          cursoId: insc.cursoId,
          fecha: insc.fecha,
        });
      }
    }
  }

  guardar(): void {
    if (this.form.invalid) return;

    if (this.idEditar) {
      this.inscripcionesService.actualizar(this.idEditar, this.form.value);
    } else {
      const nueva: Inscripcion = {
        id: this.inscripcionesService.nuevoId(),
        ...this.form.value,
      };
      this.inscripcionesService.crear(nueva);
    }

    this.router.navigate(['/inscripciones']);
  }

  cancelar(): void {
    this.router.navigate(['/inscripciones']);
  }
}
