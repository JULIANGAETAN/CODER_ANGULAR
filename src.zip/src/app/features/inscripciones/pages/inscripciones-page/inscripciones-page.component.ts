import { Component } from '@angular/core';

@Component({
  selector: 'app-inscripciones-page',
  templateUrl: './inscripciones-page.component.html'
})
export class InscripcionesPageComponent {}
