export interface Inscripcion {
  id: string;
  alumnoId: string;
  cursoId: string;
  fecha: string; // yyyy-mm-dd
}
