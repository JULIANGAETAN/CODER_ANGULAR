// src/app/features/alumnos/alumnos.module.ts
import { NgModule } from '@angular/core';

@NgModule({})
export class AlumnosModule {}
