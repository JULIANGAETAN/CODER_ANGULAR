export interface Curso {
  id: string;
  nombre: string;
  descripcion: string;
  activo: boolean;
}
