import { Component } from '@angular/core';

@Component({
  selector: 'app-cursos-page',
  templateUrl: './cursos-page.component.html'
})
export class CursosPageComponent {}
