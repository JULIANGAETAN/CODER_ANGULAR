import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatIconModule } from '@angular/material/icon';

import { CursosService } from '../../services/cursos.service';
import { Curso } from '../../models/curso.model';

@Component({
  selector: 'app-cursos-list',
  standalone: true,
  templateUrl: './cursos-list.component.html',
  styleUrls: ['./cursos-list.component.scss'],
  imports: [
    CommonModule,
    FormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatTableModule,
    MatPaginatorModule,
    MatIconModule,
  ],
})
export class CursosListComponent implements OnInit {
  cursos: Curso[] = [];
  filtro = '';

  columnas = ['id', 'nombre', 'descripcion', 'activo', 'acciones'];

  constructor(
    private cursosService: CursosService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.cargar();
  }

  cargar(): void {
    this.cursosService.listar().subscribe((lista) => (this.cursos = lista));
  }

  aplicarFiltro(): Curso[] {
    const f = this.filtro.toLowerCase();
    return this.cursos.filter(
      (c) =>
        c.nombre.toLowerCase().includes(f) ||
        (c.descripcion ?? '').toLowerCase().includes(f)
    );
  }

  nuevo(): void {
    this.router.navigate(['/cursos/nuevo']);
  }

  editar(curso: Curso): void {
    // 👈 acá estaba tu problema: ahora va a /cursos/:id
    this.router.navigate(['/cursos', curso.id]);
  }

  eliminar(id: string): void {
    this.cursosService.eliminar(id);
    this.cargar();
  }

  restaurar(): void {
    this.cursosService.reset();
    this.cargar();
  }
}
