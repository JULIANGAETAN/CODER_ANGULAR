export interface ListItem {
  name: string;
  icon: string;
  url: string;
}
