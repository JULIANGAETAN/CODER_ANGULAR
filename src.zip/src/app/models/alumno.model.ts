// src/app/models/alumno.model.ts
export interface Alumno {
  id: string;
  nombre: string;
  apellido: string;
  email: string;
  activo: boolean;
}
