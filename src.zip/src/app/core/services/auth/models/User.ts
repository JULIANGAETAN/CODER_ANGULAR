export interface User {
  email: string;
  sub: number;
  role: string;
}
