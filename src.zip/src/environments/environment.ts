export const environment = {
  apiUrl: 'https://coderangularbackend.onrender.com/api/',
};
